-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2023 at 06:43 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `easymart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_password` char(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_email`, `admin_password`) VALUES
(1, 'gohiljanvi90@gmail.com', 'Ad@123');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(8) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `registration_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `password`, `phone`, `address`, `registration_date`) VALUES
(1, 'John Doe', 'john@example.com', 'hashedpa', '123-456-7890', '123 Main St, City', '2023-01-15'),
(2, 'Jane Smith', 'jane@example.com', 'hashedpa', '987-654-3210', '456 Elm St, Town', '2023-02-20'),
(3, 'Michael Johnson', 'michael@example.com', 'hashedpa', '555-123-4567', '789 Oak St, Village', '2023-03-10'),
(4, 'Emily Williams', 'emily@example.com', 'hashedpa', '111-222-3333', '567 Pine St, Hamlet', '2023-04-05'),
(5, 'David Brown', 'david@example.com', 'hashedpa', '444-555-6666', '890 Maple St, Suburb', '2023-05-12'),
(6, 'Sarah Wilson', 'sarah@example.com', 'hashedpa', '999-888-7777', '234 Birch St, Countryside', '2023-06-08'),
(7, 'Robert Davis', 'robert@example.com', 'hashedpa', '777-888-9999', '678 Walnut St, Outskirts', '2023-07-25'),
(8, 'Jessica Martin', 'jessica@example.com', 'hashedpa', '222-333-4444', '345 Cedar St, City', '2023-08-01'),
(9, 'William Anderson', 'william@example.com', 'hashedpa', '666-777-8888', '901 Pine St, Town', '2023-09-18'),
(10, 'Amanda White', 'amanda@example.com', 'hashedpa', '333-444-5555', '123 Oak St, City', '2023-10-11'),
(11, 'John Doe', 'john@example.com', 'pass123', '123-456-7890', '123 Main St, City', '2023-07-01'),
(12, 'Jane Smith', 'jane@example.com', 'secure45', '987-654-3210', '456 Elm St, Town', '2023-07-01'),
(13, 'Michael Johnson', 'michael@example.com', 'pswd789', '', '789 Oak Ave, Village', '2023-08-01'),
(14, 'Emily Brown', 'emily@example.com', 'secret12', '555-123-4567', '321 Pine Rd, Suburb', '2023-08-04'),
(15, 'David Williams', 'david@example.com', 'password', '444-555-6666', '', '2023-07-05'),
(16, 'Jessica Davis', 'jessica@example.com', 'p@ssw0rd', '777-888-9999', '555 Maple Ln, Hamlet', '2023-08-06'),
(17, 'Chris Wilson', 'chris@example.com', 'abc987', '', '777 Cedar Dr, County', '2023-07-07'),
(18, 'Melissa Turner', 'melissa@example.com', 'mysecret', '222-333-4444', '888 Birch Ave, Township', '2023-07-08'),
(19, 'Daniel Martinez', 'daniel@example.com', 'dannyboy', '111-222-3333', '999 Pine St, Subdivision', '2023-08-09'),
(21, 'janvi', 'janvi@gmail.com', 'Janvi@12', '9099390993', 'address', '2023-07-08'),
(22, 'himani', 'himani@gmail.com', 'Himani@1', '2342342345', 'address', '2023-08-21'),
(23, 'chand desai', 'chanddesai597@gmail.com', 'Chand@12', '9913355733', 'hmbh', '2023-08-21');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`order_id`, `customer_id`, `order_date`, `total_amount`, `payment_method`, `status`) VALUES
(1, 1, '2023-08-11', '250.00', 'Credit Card', 'Pending'),
(2, 2, '2023-08-12', '550.00', 'PayPal', 'Shipped'),
(3, 3, '2023-08-13', '100.00', 'Cash on Delivery', 'Delivered'),
(4, 4, '2023-08-14', '75.50', 'Credit Card', 'Pending'),
(5, 5, '2023-08-15', '300.00', 'PayPal', 'Shipped');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_boys`
--

CREATE TABLE `delivery_boys` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(8) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `registration_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_boys`
--

INSERT INTO `delivery_boys` (`id`, `name`, `email`, `password`, `phone`, `registration_date`) VALUES
(1, 'John Doe', 'john@example.com', 'pass123', '123-456-7890', '2023-08-01'),
(2, 'Jane Smith', 'jane@example.com', 'secure12', '987-654-3210', '2023-08-02'),
(3, 'Michael Johnson', 'michael@example.com', 'pswd789', '', '2023-08-03'),
(4, 'David Williams', 'david@example.com', 'password', '444-555-6666', '2023-08-04'),
(5, 'Emily Brown', 'emily@example.com', 'secret12', '555-123-4567', '2023-08-05');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_orders`
--

CREATE TABLE `delivery_orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `delivery_boy_id` int(11) DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_orders`
--

INSERT INTO `delivery_orders` (`id`, `customer_id`, `delivery_boy_id`, `delivery_date`, `status`, `total_amount`) VALUES
(1, 1, 1, '2023-08-11', 'Shipped', '250.00'),
(2, 2, 2, '2023-08-12', 'Delivered', '550.00'),
(3, 3, NULL, '2023-08-13', 'Pending', '100.00');

-- --------------------------------------------------------

--
-- Table structure for table `onetimepassword`
--

CREATE TABLE `onetimepassword` (
  `id` int(11) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `otp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `onetimepassword`
--

INSERT INTO `onetimepassword` (`id`, `mail`, `otp`) VALUES
(1, 'gohiljanvi90@gmail.com', '364759');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `delivery_boy_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) NOT NULL,
  `order_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_id`, `customer_id`, `product_id`, `delivery_boy_id`, `vendor_id`, `order_date`) VALUES
(1, 1, 1, 1, 1, '2023-08-11'),
(2, 2, 2, 2, 2, '2023-07-12'),
(3, 3, 3, NULL, 3, '2023-08-13');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `product_register_date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `quantity`, `category`, `brand`, `image_path`, `product_register_date`) VALUES
(1, 'pen', 'High-quality stainless steel ballpoint pen with a sleek matte finish, perfect for professional and personal use.', '20.00', 20, 'pen', 'cello', 'https://www.collinsdictionary.com/images/full/pen_525053431_1000.jpg', '2023-10-26'),
(3, 'Favicol', 'A reliable adhesive product for various paper and office needs.', '20.00', 1, 'favicol', 'favicol', 'https://cityeshops.com/wp-content/uploads/2019/12/61x5wkeEygL._SL1500_-1024x1024.jpg', '2023-07-05'),
(5, 'marker', 'A set of stationery including decorative paper and vibrant markers for creative projects.', '15.00', 1, 'marker', 'starpie', 'https://www.flightstore.com.au/assets/full/SA30001BK.jpg?20200914113003', '2023-07-05'),
(6, 'punching machine', 'A stationary punching machine: a compact tool for precise hole punching in paper and documents.', '80.00', 1, 'machine', 'kangaro', 'https://5.imimg.com/data5/SELLER/Default/2020/10/SX/GU/NY/9266715/paper-punching-machine.jpg', '2023-07-05'),
(7, 'carbon paper', 'A versatile tool for creating duplicate copies by transferring handwritten or typed content onto additional sheets.', '10.00', 10, 'paper', 'paper', 'https://tse4.mm.bing.net/th?id=OIP.RBhzZsvYFRP9dXbu65UuOwHaHa&pid=Api&P=0&h=180', '2023-07-05'),
(8, 'calculator', 'A stationary calculator, featuring a sleek design and advanced functions for efficient mathematical computations.', '150.00', 1, 'matchin', 'casio', 'https://pngimg.com/uploads/calculator/calculator_PNG7953.png', '2023-07-05'),
(9, 'notebook', 'A high-quality stationary notebook perfect for capturing your thoughts and ideas.', '300.00', 4, 'books', 'classmate', 'https://rukminim1.flixcart.com/image/832/832/kf2v3ww0/diary-notebook/e/4/g/classmate-02105003-original-imafvm2cmy6uas4b.jpeg?q=70', '2023-07-05'),
(10, 'post-it-note', 'Compact, colorful adhesive sheets for quick reminders and organization.', '100.00', 5, 'paper', 'clipart', 'https://tse2.mm.bing.net/th?id=OIP.E7eng6qzyDJM1LjJzS5rswHaIo&pid=Api&P=0&h=180', '2023-07-05'),
(15, 'scissor', 'High-quality stationary scissors designed for precise and effortless cutting.', '50.00', 1, 'scissor', 'Fiskars', 'https://3.bp.blogspot.com/-2qMh_E2fG_U/UwW2vu1iQqI/AAAAAAAAHjk/bay1o6YSdzU/s1600/diy+fabric+hoop+earrings+supplies.jpg', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `removed_products`
--

CREATE TABLE `removed_products` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `removal_date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL,
  `address` varchar(200) NOT NULL,
  `website` varchar(100) DEFAULT NULL,
  `shop_name` varchar(100) NOT NULL,
  `shop_address` varchar(200) NOT NULL,
  `registration_date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `email`, `phone`, `password`, `address`, `website`, `shop_name`, `shop_address`, `registration_date`) VALUES
(1, 'Vendor 1', 'vendor1@example.com', '123-456-7890', 'pass123', '123 Main St, City', 'www.vendor1.com', 'Shop A', '456 Elm St, City', '2023-08-01'),
(2, 'Vendor 2', 'vendor2@example.com', '987-654-3210', 'secure12', '789 Oak Ave, Town', 'www.vendor2.com', 'Shop B', '789 Maple St, Town', '2023-08-02'),
(3, 'Vendor 3', 'vendor3@example.com', '555-123-4567', 'vendor34', '321 Pine Rd, Suburb', 'www.vendor3.com', 'Shop C', '123 Oak Ln, Suburb', '2023-08-03'),
(4, 'Vendor 4', 'vendor4@example.com', '444-555-6666', 'shoppass', '555 Cedar Dr, County', NULL, '', '', '2023-08-04'),
(5, 'Vendor 5', 'vendor5@example.com', '777-888-9999', 'mystore', '777 Birch Ave, Village', 'www.vendor5.com', 'Shop D', '888 Pine Ave, Village', '2023-08-05'),
(6, 'Vendor 6', 'vendor6@example.com', '111-222-3333', 'secret12', '111 Market St, City', 'www.vendor6.com', 'Shop E', '222 Grove Rd, City', '2023-08-06'),
(7, 'Vendor 7', 'vendor7@example.com', '666-777-8888', 'vend1234', '666 Plaza Ave, Town', 'www.vendor7.com', 'Shop F', '777 Park St, Town', '2023-08-07'),
(8, 'Vendor 8', 'vendor8@example.com', '222-333-4444', 'mypass12', '222 Square Rd, Suburb', 'www.vendor8.com', 'Shop G', '333 Circle Ln, Suburb', '2023-08-08'),
(9, 'Vendor 9', 'vendor9@example.com', '999-888-7777', 'vendor99', '999 Mall St, County', 'www.vendor9.com', 'Shop H', '888 Center Rd, County', '2023-08-09'),
(10, 'Vendor 10', 'vendor10@example.com', '555-444-3333', 'shop999', '555 Boutique Rd, Village', 'www.vendor10.com', 'Shop I', '444 Boutique Ln, Village', '2023-08-10');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_products`
--

CREATE TABLE `vendor_products` (
  `id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `product_register_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendor_products`
--

INSERT INTO `vendor_products` (`id`, `vendor_id`, `product_register_date`) VALUES
(1, 1, '2023-08-01'),
(2, 2, '2023-08-02'),
(3, 3, '2023-08-03'),
(4, 4, '2023-08-04'),
(5, 5, '2023-08-05'),
(6, 6, '2023-08-06'),
(7, 7, '2023-08-07'),
(8, 8, '2023-08-08'),
(9, 9, '2023-08-09'),
(10, 10, '2023-08-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_orders`
--
ALTER TABLE `delivery_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `delivery_boy_id` (`delivery_boy_id`);

--
-- Indexes for table `onetimepassword`
--
ALTER TABLE `onetimepassword`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `delivery_boy_id` (`delivery_boy_id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `removed_products`
--
ALTER TABLE `removed_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor_products`
--
ALTER TABLE `vendor_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `delivery_orders`
--
ALTER TABLE `delivery_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `onetimepassword`
--
ALTER TABLE `onetimepassword`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `vendor_products`
--
ALTER TABLE `vendor_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD CONSTRAINT `customer_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Constraints for table `delivery_orders`
--
ALTER TABLE `delivery_orders`
  ADD CONSTRAINT `delivery_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `delivery_orders_ibfk_2` FOREIGN KEY (`delivery_boy_id`) REFERENCES `delivery_boys` (`id`);

--
-- Constraints for table `removed_products`
--
ALTER TABLE `removed_products`
  ADD CONSTRAINT `removed_products_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `vendor_products`
--
ALTER TABLE `vendor_products`
  ADD CONSTRAINT `vendor_products_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
