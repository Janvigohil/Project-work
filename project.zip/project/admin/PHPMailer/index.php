<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

use PHPMailer\PHPMailer\PHPMailer;

// Load Composer's autoloader
require 'vendor/autoload.php';
$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 465;
$mail->SMTPSecure = 'ssl';
$mail->CharSet = 'utf-8';
$mail->SMTPAuth = true;
$mail->Username = 'forpc81@gmail.com';
$mail->Password = 'xocemnaattbenwen';
$mail->SetFrom('forpc81@gmail.com');
$mail->addAddress('forpc81@gmail.com');
// $mail->addReplyTo('radhikachodavdiya@gmail.com', 'radhikachodavdiya');;
$mail->SMTPDebug = false;
$mail->IsHTML(true);
$message = '
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Free Web tutorials" />
        <title>Mail</title>
        <meta name="keywords" content="HTML, CSS, JavaScript" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    </head>
    
        <body style="width: 100%; font-family: \'Inter\', sans-serif; margin: 0; padding: 0; background-color: #ffffff;">
           hi dude
        </body>
    </html>';

$mail->Subject = 'New User Registered';
$mail->Body = $message;

if (!$mail->send()) {
    echo '<script>alert("Message could not be sent.");</script>';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
