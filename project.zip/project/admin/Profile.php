<?php
session_start();

include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');

include 'includes/DBconnection.php';

$sql = "SELECT * FROM admin";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $email = $row["admin_email"];
        $password = $row["admin_password"];
    }
} else {
    echo "0 results";
}

$stmt->close();
$conn->close();
?>

<script>
    function editProfile() {
        document.getElementById("profile-info").style.display = "none";
        document.getElementById("edit-form").style.display = "block";
        document.getElementById("new-name").value = document.getElementById("name").textContent;
        document.getElementById("new-email").value = document.getElementById("email").textContent;
    }

    function saveProfile() {
        var newName = document.getElementById("new-name").value;
        var newEmail = document.getElementById("new-email").value;

        document.getElementById("name").textContent = newName;
        document.getElementById("email").textContent = newEmail;

        document.getElementById("profile-info").style.display = "block";
        document.getElementById("edit-form").style.display = "none";
    }
</script>

<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
        <div class="container">
            <div class="row">
                <div class="col-sm-3"></div>
                <div class="col-sm-6">
                    <div style="width: 500px;">
                        <main class="container mt-4">
                            <section id="profile-info" class="container mt-5">
                                <h2 class="mb-4">Profile Information</h2>
                                <div class="row">
                                    <div class="col-md-9">
                                        <p class="mb-2 lead"><strong>Name: </strong>Janvi</p>
                                        <p class="mb-2 lead"><strong>Email: </strong><?php echo $email; ?></p>
                                        <p class="mb-2 lead"><strong>Joined: </strong> January 1, 2022</p>
                                        <a href="ChangePass.php"><p class="mb-2">Change Password <span id="changepass"></span></p></a>
                                        <button id="edit-btn" class="btn btn-primary" onclick="editProfile()">Edit</button>
                                    </div>
                                </div>
                            </section>

                            <section id="edit-form" style="display:none;" class="border p-4">
                                <h2 class="mb-3">Edit Profile</h2>
                                <form method="post">
                                   
                                    <div class="mb-3">
                                        <label for="new-email" class="form-label">Email:</label>
                                        <input type="email" name="email" class="form-control" id="new-email" required>
                                    </div>
                                    <!-- Add more fields for editing as needed -->
                                    <button type="submit" name="submit" class="btn btn-success" onclick="saveProfile()">Save</button>
                                </form>
                            </section>
                        </main>
                    </div>
                </div>
                <div class="col-sm-3"></div>
            </div>
        </div>
    </div>
</div>

<?php
include ("includes/scripts.php");
?>

<?php
include ("includes/DBconnection.php");

if (isset($_POST["submit"])) {
    $s_email = $_SESSION["admin_email"];
  
    $email = $_POST["email"];

    $sql = "UPDATE admin SET  admin_email=? WHERE admin_email=?";

    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ss", $email, $s_email);

        if ($stmt->execute()) {
            
            $_SESSION["admin_email"] = $email; // Update session with new name
        } else {
            echo "Error updating record: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

?>
