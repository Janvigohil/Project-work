<?php

// Database Connection
include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';

// Search Query
$Sname = $_POST['name'];
$sql = "SELECT * FROM customers WHERE name LIKE '%$Sname%'"; 
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo '<div class="container mt-5">
            <table class="table table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>Customer Id</th>
                        <th>Customer Name</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Address</th>
                        <th>Registration Date</th>
                    </tr>
                </thead>
                <tbody>';

    // Output data for each row
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . @$row['id'] . '</td>';
        echo '<td>' . @$row['name'] . '</td>';
        echo '<td>' . @$row['email'] . '</td>';
        echo '<td>' . @$row['phone'] . '</td>';
        echo '<td>' . @$row['address'] . '</td>';
        echo '<td>' . @$row['registration_date'] . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table></div>';
} else {
    echo '<div class="container mt-5">0</div>';
}

$conn->close();
?>
