 <?php
 
 $vname = $_POST['Vname'];
    
                echo '<div class="container mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Vendor Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact No</th>
                <th>Address</th>
                <th>Shop Name</th>
                <th>Shop Address</th>
                <th>Register Date</th>
            </tr>
        </thead>
        <tbody>';

// Pagination parameters for Vendors
                 include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';
                $entries_per_page_vendor = 10;
                $page_vendor = isset($_GET['page_vendor']) ? $_GET['page_vendor'] : 1;
                $start_vendor = ($page_vendor - 1) * $entries_per_page_vendor;

                $sql_vendor = "SELECT * FROM vendors WHERE name LIKE '%$vname%'";
                $result_vendor = $conn->query($sql_vendor);

                if ($result_vendor->num_rows > 0) {
                    while ($row = $result_vendor->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . @$row['id'] . '</td>';
                        echo '<td>' . @$row['name'] . '</td>';
                        echo '<td>' . @$row['email'] . '</td>';
                        echo '<td>' . @$row['phone'] . '</td>';
                        echo '<td>' . @$row['address'] . '</td>';
                        echo '<td>' . @$row['shop_name'] . '</td>';
                        echo '<td>' . @$row['shop_address'] . '</td>';
                        echo '<td>' . @$row['registration_date'] . '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="8">No records found</td></tr>';
                }

                echo '</tbody>
    </table>

    <nav aria-label="Page navigation">
        <ul class="pagination">';
                $sql_vendor_count = "SELECT COUNT(*) AS total FROM vendors";
                $result_vendor_count = $conn->query($sql_vendor_count);
                $row_vendor = $result_vendor_count->fetch_assoc();
                $total_entries_vendor = $row_vendor['total'];
                $total_pages_vendor = ceil($total_entries_vendor / $entries_per_page_vendor);

                for ($i = 1; $i <= $total_pages_vendor; $i++) {
                    echo '<li class="page-item' . ($page_vendor == $i ? ' active' : '') . '"><a class="page-link" href="?page_vendor=' . $i . '">' . $i . '</a></li>';
                }

                echo '</ul>
    </nav>
</div>';
                
    ?>