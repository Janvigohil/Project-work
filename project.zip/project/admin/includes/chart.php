<?php

include 'DBconnection.php';

$sql = "SELECT x_value, y_value FROM chart_data";
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $data[] = array("x" => $row["x_value"], "y" => $row["y_value"]);
  }
} else {
  echo "0 results";
}

$conn->close();
?>
