<?php
                echo'  <div class="container mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Customer Id</th>
                <th>Customer name</th>
                <th>Email</th>
                <th>Contact no</th>
                <th>Address</th>
                <th>Registration Date</th>
            </tr>
        </thead>
        <tbody>';

                include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';

                // Pagination parameters
                $entries_per_page = 10;
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $start = ($page - 1) * $entries_per_page;

                $sql = "SELECT * FROM customers LIMIT $start, $entries_per_page";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . @$row['id'] . '</td>';
                        echo '<td>' . @$row['name'] . '</td>';
                        echo '<td>' . @$row['email'] . '</td>';
                        echo '<td>' . @$row['phone'] . '</td>';
                        echo '<td>' . @$row['address'] . '</td>';
                        echo '<td>' . @$row['registration_date'] . '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="6">No records found</td></tr>';
                }


                echo'   </tbody>
                    </table>

                    <nav aria-label="Page navigation">
                        <ul class="pagination">';
                $sql = "SELECT COUNT(*) AS total FROM customers";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                $total_entries = $row['total'];
                $total_pages = ceil($total_entries / $entries_per_page);

                for ($i = 1; $i <= $total_pages; $i++) {
                    echo '<li class="page-item' . ($page == $i ? ' active' : '') . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
                }

                echo'   </ul>
                    </nav>
                </div>';
                ?>