<?php

session_start();

include_once 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';

if (isset($_POST["Logout"])) {
    // Check if the user is logged in
    if (isset($_SESSION['admin_email'])) {
        // User is logged in, perform logout
        session_unset(); // Unset all session variables
        session_destroy(); // Destroy the session
    }

// Redirect to the login page after logout
    header("Location: login.php");
    exit();
}

if (isset($_POST["Login"])) {

    $email = $_POST['email'];
    $password = $_POST["pass"];

    $login_query = "SELECT * FROM admin WHERE admin_email='$email' AND admin_password='$pass'";
    $login_query_run = mysqli_query($conn, $login_query);

    if ($login_query_run->num_rows > 0) {
        $_SESSION["admin_email"] = $email;
        $_SESSION["Password"] = $pass;

        header("Location: index.php");
        exit();
    } else {
        $_SESSION["Message"] = "Invalid Author or Password";
        header("Location: admin\login.php");
        exit();
    }
} else {
   echo '<h2>You are not allowed to access this file</h2>';
   header("Location: /project/admin/login.php");
   exit();
}


?>

