<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
?>

<?php
include 'includes/DBconnection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM Products WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        ?>

        <div class="container mt-5 w-50">
            <form method="post">

                <h2>Edit Products Details</h2>
                <br>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $row['name']; ?>">
                </div>

                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description"><?php echo $row['description']; ?></textarea>
                </div>

                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="text" class="form-control" id="price" name="price" value="<?php echo $row['price']; ?>">
                </div>

                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>">
                </div>

                <div class="form-group">
                    <label for="category">Category:</label>
                    <input type="text" class="form-control" id="category" name="category" value="<?php echo $row['category']; ?>">
                </div>

                <div class="form-group">
                    <label for="brand">Brand:</label>
                    <input type="text" class="form-control" id="brand" name="brand" value="<?php echo $row['brand']; ?>">
                </div>

                <div class="form-group">
                    <label for="image_path">Image Path:</label>
                    <input type="text" class="form-control" id="image_path" name="image_path" value="<?php echo $row['image_path']; ?>">
                </div>

                <div class="form-group">
                    <label for="product_register_date">Register Date:</label>
                    <input type="date" class="form-control" id="product_register_date" name="product_register_date" value="<?php echo $row['product_register_date']; ?>">
                </div>

                <button type="submit" name="submit"  class="btn btn-primary">Submit</button>
            </form>
        </div>

        <?php
    } else {
        echo "Record not found.";
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
<?php
include 'includes/DBconnection.php';

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $category = $_POST['category'];
    $brand = $_POST['brand'];
    $image_path = $_POST['image_path'];
    $product_register_date = $_POST['product_register_date'];

    $sql = "UPDATE Products SET name=?, description=?, price=?, quantity=?, category=?, brand=?, image_path=?, product_register_date=? WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdsssssi", $name, $description, $price, $quantity, $category, $brand, $image_path, $product_register_date, $id);

    if ($stmt->execute()) {
        echo "Record updated successfully.";
        echo '<script>window.location.href = "Products.php";</script>'; // Redirect using JavaScript
        exit(); 
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
} else {
}

$conn->close();
?>



<?php
include ("includes/scripts.php");
include ("includes/footer.php");
?>