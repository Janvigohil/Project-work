<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
?>



<style>

    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

    @keyframes bake-pie {
        from {
            transform: rotate(0deg) translate3d(0, 0, 0);
        }
    }

    body {
        font-family: "Open Sans", Arial;
        background: #EEE;
    }

    main {
        width: 400px;
        margin: 30px auto;
    }


    .pieID {
        display: inline-block;
        vertical-align: top;
    }

    .pie {
        height: 200px;
        width: 200px;
        position: relative;
        margin: 0 30px 30px 0;
    }

    .pie::before {
        content: "";
        display: block;
        position: absolute;
        z-index: 1;
        width: 100px;
        height: 100px;
        background: #EEE;
        border-radius: 50%;
        top: 50px;
        left: 50px;
    }

    .pie::after {
        content: "";
        display: block;
        width: 120px;
        height: 2px;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        box-shadow: 0 0 3px 4px rgba(0, 0, 0, 0.1);
        margin: 220px auto;

    }

    .slice {
        position: absolute;
        width: 200px;
        height: 200px;
        clip: rect(0px, 200px, 200px, 100px);
        animation: bake-pie 1s;
    }

    .slice span {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        background-color: black;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        clip: rect(0px, 200px, 200px, 100px);
    }

    .legend {
        list-style-type: none;
        padding: 0;
        margin: 0;
        background: #FFF;
        padding: 15px;
        font-size: 13px;
        box-shadow: 1px 1px 0 #DDD,
            2px 2px 0 #BBB;
    }

    .legend li {
        width: 170px;
        height: 1.25em;
        margin-bottom: 0.7em;
        padding-left: 0.5em;
        border-left: 1.25em solid black;
    }

    .legend em {
        font-style: normal;
    }

    .legend span {
        float: right;
    }

    footer {
        position: fixed;
        bottom: 0;
        right: 0;
        font-size: 13px;
        background: #DDD;
        padding: 5px 10px;
        margin: 5px;
    }

</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#click').click(function (event) {
            event.preventDefault(); // Prevent default form submission behavior
            var query = $("#Prodname").val();
            if (query !== '') {
                // Make an Ajax request
                $.ajax({
                    url: 'searchprod.php', // Change to search.php if that's the correct file name
                    type: 'POST',
                    data: {pname: query}, // Adjust to match your PHP code
                    success: function (response) {
                        $('#searchResults').html(response);
                    },
                    error: function (xhr, status, error) {
                        console.log(error); // Log the error to the console for debugging
                        alert('Error occurred while processing the request.');
                    }
                });

            } else {
                $('#searchResults').html('');
            }
        });
    });


</script>

<div class="container">
    <div class="container py-5">
        <div class="text-center">
            <h1 class="mb-4">Product Search</h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="post" id="searchForm" class="mb-3">
                    <div class="input-group">
                        <input type="text" id="Prodname" class="form-control" placeholder="Enter Name">
                        <div class="input-group-append">
                            <button id="click" type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div id="searchResults" class="container"></div>

    <h3>Products</h3>

    <?php
    echo '<div class="container mt-5">
    <form method="GET"><table class="table table-striped">
        <thead>
            <tr>
                <th>Products Id</th>
                <th>Name</th>
                <th>Description</th>
                <th>price</th>
                <th>Quantity</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Images</th>
                <th>RegisterDate</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>';

    include 'includes/DBconnection.php';
// Pagination parameters for Products
    $entries_per_page_Products = 10;
    $page_Products = isset($_GET['page_Products']) ? $_GET['page_Products'] : 1;
    $start_Products = ($page_Products - 1) * $entries_per_page_Products;

    $sql_Products = "SELECT * FROM Products LIMIT $start_Products, $entries_per_page_Products";
    $result_Products = $conn->query($sql_Products);

    if ($result_Products->num_rows > 0) {
        while ($row = $result_Products->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . @$row['id'] . '</td>';
            echo '<td>' . @$row['name'] . '</td>';
            echo '<td>' . @$row['description'] . '</td>';
            echo '<td>' . @$row['price'] . '</td>';
            echo '<td>' . @$row['quantity'] . '</td>';
            echo '<td>' . @$row['category'] . '</td>';
            echo '<td>' . @$row['brand'] . '</td>';
            echo '<td><img src="' . @$row['image_path'] . '" height="100px" width="100px"></td>';
            echo '<td>' . @$row['product_register_date'] . '</td>';
            echo '<td>' . '<a href="Edit.php?id=' . @$row['id'] . '"><input type="button" class="btn btn-primary" value="Edit" /></a>' . '</td>';
            echo '<td><form method="POST">
            <input type="hidden" name="product_id" value="' . @$row['id'] . '">
            <input type="submit" name="del" class="btn btn-primary" value="Delete"/></form>';
            echo '</td></tr>';
        }
    } else {
        echo '<tr><td colspan = "8">No records found</td></tr>';
    }


    include 'includes/DBconnection.php';

    if (isset($_POST['del'])) {
        $product_id = $_POST['product_id'];

        // Assuming you have a table named 'products'
        $sql = "DELETE FROM products WHERE id = $product_id";

        if ($conn->query($sql) === TRUE) {
            
        } else {
            echo "Error deleting product: " . $conn->error;
        }
    }

    ?>





</tbody>
</table></form>

<nav aria-label="Page navigation">
    <ul class="pagination">';
     <?php   $sql_Products_count = "SELECT COUNT(*) AS total FROM Products";
        $result_Products_count = $conn->query($sql_Products_count);
        $row_Products = $result_Products_count->fetch_assoc();
        $total_entries_Products = $row_Products['total'];
        $total_pages_Products = ceil($total_entries_Products / $entries_per_page_Products);

        for ($i = 1; $i <= $total_pages_Products; $i++) {
        echo '<li class="page-item' . ($page_Products == $i ? ' active' : '') . '"><a class="page-link" href="?page_Products=' . $i . '">' . $i . '</a></li>';
        }

        echo '</ul>
</nav>
</div>';
?>


<br><br>
</div>

<?php
include ("includes/scripts.php");
include ("includes/footer.php");
?>