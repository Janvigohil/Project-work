<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <link rel="icon" href="./images/fj.png" type="image/gif" sizes="16x16">
        <title>Easy Mart</title>

        <meta charset="utf-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">

        <link rel="stylesheet" href="css/animate.css">

        <link rel="stylesheet" href="css/owl.carousel.min.css">

        <link rel="stylesheet" href="css/owl.theme.default.min.css">

        <link rel="stylesheet" href="css/magnific-popup.css">

        <link rel="stylesheet" href="css/aos.css">

        <link rel="stylesheet" href="css/ionicons.min.css">

        <link rel="stylesheet" href="css/bootstrap-datepicker.css">

        <link rel="stylesheet" href="css/flaticon.css">

        <link rel="stylesheet" href="css/icomoon.css">

        <link rel="stylesheet" href="css/style.css">

        <style>
            body {
                background: #eee;
            }

            .card {
                box-shadow: 0 20px 27px 0 rgb(0 0 0 / 5%);
            }

            .card {
                position: relative;
                display: flex;
                flex-direction: column;
                min-width: 0;
                word-wrap: break-word;
                background-color: #fff;
                background-clip: border-box;
                border: 0 solid rgba(0, 0, 0, .125);
                border-radius: 1rem;
            }

            .img-thumbnail {
                padding: .25rem;
                background-color: #ecf2f5;
                border: 1px solid #dee2e6;
                border-radius: .25rem;
                max-width: 100%;
                height: auto;
            }

            .avatar-lg {
                height: 150px;
                width: 150px;
            }
        </style>

    </head>

    <body style="background:#4e73df;">

        <div class="container">
            <br>
            <div class="row">
                <div class="col-lg-5 col-md-7 mx-auto my-auto">
                    <div class="card">
                        <div class="card-body px-lg-5 py-lg-5">
                            <center>
                                <br>
                                <img src="https://th.bing.com/th/id/OIP.X-rBsFWmhhNmXyeUG69QFgHaF3?pid=ImgDet&rs=1" height="100" width="100"><br>
                                <h2 class="text-info">Create Password</h2>
                                <br>
                            </center>
                            <form method="post">
                                <form method="post">
                                    
                                    <div class="form-group">
                                        <label for="new_password">New Password:</label>
                                        <input type="password" id="new_password" name="new_password" class="form-control" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="confirm_password">Confirm New Password:</label>
                                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                                    </div>
                                    <br>
                                    <input type="submit" name="change" class="btn btn-primary" value="Change Password"/>                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
        include 'includes/DBconnection.php';

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $new_password = $_POST["new_password"];
            $confirm_password = $_POST["confirm_password"];
            $_email = $_SESSION["admin_email"];

            // Validate passwords
            if ($new_password !== $confirm_password) {
                echo "New passwords do not match.";
            } else {
                // Check if current password is correct
                $result = $conn->query("SELECT admin_password FROM admin WHERE admin_email = '$_email'");

                if ($result->num_rows == 1) {
                    $row = $result->fetch_assoc();
                    $db_password = $row["admin_password"];

                    // Update the password
                    $update_sql = "UPDATE admin SET admin_password = '$new_password' WHERE admin_email = '$_email'";

                    if ($conn->query($update_sql) === TRUE) {
                        echo "Password updated successfully.";
                        echo '<script>window.location.href = "login.php";</script>';
                    } else {
                        echo "Error updating password: " . $conn->error;
                    }
                } else {
                    echo "User not found.";
                }

                $result->close();
            }
        }

        $conn->close();
        ?>


