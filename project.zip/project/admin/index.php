<?php
session_start(); // Start the session (if not already started)
// Check if the user is logged in
if (!isset($_SESSION['admin_email'])) {
    header("Location: login.php");
    exit();
}
?>

<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
include ("includes/scripts.php");
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

    @keyframes bake-pie {
        from {
            transform: rotate(0deg) translate3d(0, 0, 0);
        }
    }

    body {
        font-family: "Open Sans", Arial;
        background: #EEE;
    }

    main {
        width: 400px;
        margin: 30px auto;
    }


    .pieID {
        display: inline-block;
        vertical-align: top;
    }

    .pie {
        height: 200px;
        width: 200px;
        position: relative;
        margin: 0 30px 30px 0;
    }

    .pie::before {
        content: "";
        display: block;
        position: absolute;
        z-index: 1;
        width: 100px;
        height: 100px;
        background: #EEE;
        border-radius: 50%;
        top: 50px;
        left: 50px;
    }

    .pie::after {
        content: "";
        display: block;
        width: 120px;
        height: 2px;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        box-shadow: 0 0 3px 4px rgba(0, 0, 0, 0.1);
        margin: 220px auto;

    }

    .slice {
        position: absolute;
        width: 200px;
        height: 200px;
        clip: rect(0px, 200px, 200px, 100px);
        animation: bake-pie 1s;
    }

    .slice span {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        background-color: black;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        clip: rect(0px, 200px, 200px, 100px);
    }

    .legend {
        list-style-type: none;
        padding: 0;
        margin: 0;
        background: #FFF;
        padding: 15px;
        font-size: 13px;
        box-shadow: 1px 1px 0 #DDD,
            2px 2px 0 #BBB;
    }

    .legend li {
        width: 170px;
        height: 1.25em;
        margin-bottom: 0.7em;
        padding-left: 0.5em;
        border-left: 1.25em solid black;
    }

    .legend em {
        font-style: normal;
    }

    .legend span {
        float: right;
    }

    footer {
        position: fixed;
        bottom: 0;
        right: 0;
        font-size: 13px;
        background: #DDD;
        padding: 5px 10px;
        margin: 5px;
    }

</style>
<!-- Begin Page Content -->

<?php
include 'includes/DBconnection.php';

$sql = "SELECT DISTINCT MONTH(registration_date) as month, COUNT(*) as count FROM customers GROUP BY MONTH(registration_date)";

$result = $conn->query($sql);

$months = [];
$count = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $months[date("F", mktime(0, 0, 0, $row['month'], 1))] = $row['count'];
    }
}

$conn->close();
?>
<div class="container">
    <div class="row">
        <div class="col-sm-9">
            <br>
            <h2><img src="img/8EE0657D-AF19-4092-ACEE-1AD1748D9C39.png" height="50" width="50">&nbsp;&nbsp;&nbsp;&nbsp;Customer Registered</h2>
            <br>
            <canvas id="customerChart" width="400" height="200"></canvas>
            <script>
                var ctx = document.getElementById('customerChart').getContext('2d');

                var chart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode(array_keys($months)); ?>,
                        datasets: [{
                                label: 'Customers Registered',
                                data: <?php echo json_encode(array_values($months)); ?>,
                                backgroundColor: [
                                    'rgba(255, 99, 132, 0.7)',
                                    'rgba(54, 162, 235, 0.7)',
                                    'rgba(255, 206, 86, 0.7)'
                                ],
                                borderColor: [
                                    'rgba(255, 99, 132, 1)',
                                    'rgba(54, 162, 235, 1)',
                                    'rgba(255, 206, 86, 1)'
                                ]
                            }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: Math.max.apply(Math, <?php echo json_encode(array_values($months)); ?>) + 1
                            }
                        }
                    }
                });
            </script>
        </div>

        <div class="col-sm-3">
            <table class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>Month</th>
                        <th>Customers Registered</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($months as $month => $count) { ?>
                        <tr>
                            <td><?php echo $month; ?></td>
                            <td><?php echo $count; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

        </div>
    </div>
    <br><br>
</div>

<div class="row">
    <div class="col-sm-9">
        <?php
        include 'includes/DBconnection.php';
        $query = "SELECT MONTH(order_date) AS month, COUNT(*) AS total_orders FROM customer_orders GROUP BY MONTH(order_date)";
        $result = mysqli_query($conn, $query);

// Step 3: Format Data for Chart.js
        $data = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $data['months'][] = date('M', mktime(0, 0, 0, $row['month'], 1));
            $data['orders'][] = $row['total_orders'];
        }
        ?>


        <canvas id="ordersChart" width="400" height="200"></canvas>

        <script>
            var ctx = document.getElementById('ordersChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?= json_encode($data['months']) ?>,
                    datasets: [{
                            label: 'Total Orders',
                            data: <?= json_encode($data['orders']) ?>,
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1
                        }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>


    </div>
</div>
</div>

</div>


