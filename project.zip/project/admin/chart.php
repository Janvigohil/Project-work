<?php
session_start(); // Start the session (if not already started)
// Check if the user is logged in
//if (!isset($_SESSION['admin_email'])) {
//    header("Location: login.php");
//    exit();
//}
?>

<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
?>
<style>

    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

    @keyframes bake-pie {
        from {
            transform: rotate(0deg) translate3d(0, 0, 0);
        }
    }

    body {
        font-family: "Open Sans", Arial;
        background: #EEE;
    }

    main {
        width: 400px;
        margin: 30px auto;
    }


    .pieID {
        display: inline-block;
        vertical-align: top;
    }

    .pie {
        height: 200px;
        width: 200px;
        position: relative;
        margin: 0 30px 30px 0;
    }

    .pie::before {
        content: "";
        display: block;
        position: absolute;
        z-index: 1;
        width: 100px;
        height: 100px;
        background: #EEE;
        border-radius: 50%;
        top: 50px;
        left: 50px;
    }

    .pie::after {
        content: "";
        display: block;
        width: 120px;
        height: 2px;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        box-shadow: 0 0 3px 4px rgba(0, 0, 0, 0.1);
        margin: 220px auto;

    }

    .slice {
        position: absolute;
        width: 200px;
        height: 200px;
        clip: rect(0px, 200px, 200px, 100px);
        animation: bake-pie 1s;
    }

    .slice span {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        background-color: black;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        clip: rect(0px, 200px, 200px, 100px);
    }

    .legend {
        list-style-type: none;
        padding: 0;
        margin: 0;
        background: #FFF;
        padding: 15px;
        font-size: 13px;
        box-shadow: 1px 1px 0 #DDD,
            2px 2px 0 #BBB;
    }

    .legend li {
        width: 170px;
        height: 1.25em;
        margin-bottom: 0.7em;
        padding-left: 0.5em;
        border-left: 1.25em solid black;
    }

    .legend em {
        font-style: normal;
    }

    .legend span {
        float: right;
    }

    footer {
        position: fixed;
        bottom: 0;
        right: 0;
        font-size: 13px;
        background: #DDD;
        padding: 5px 10px;
        margin: 5px;
    }

</style>
</head>

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">



        <!-- Begin Page Content -->
        <div class="container-fluid">


            <section class="d-flex " >
                <div class="pieID pie">

                </div>
                <ul class="pieID legend">
                    <li>

                        <em>Customer</em>
                        <span><?php
                            include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';
                            $sql = "SELECT COUNT(*) AS total_customers FROM customers";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                // Output data for each row
                                while ($row = $result->fetch_assoc()) {
                                    echo $row['total_customers'];
                                }
                            } else {
                                echo "0 results";
                            }
                            ?>
                        </span>
                    </li>
                    <li>
                        <em>Vendor</em>
                        <span><?php
                            $sql = "SELECT COUNT(*) AS total_vendor FROM vendors";
                            $stmt = $conn->prepare($sql);

                            if ($stmt) {
                                $stmt->execute();
                                $stmt->bind_result($total_vendor);
                                $stmt->fetch();

                                echo $total_vendor;

                                $stmt->close();
                            } else {
                                echo "Error in prepared statement: " . $conn->error;
                            }
                            ?>
                        </span>
                    </li>
                    <li>
                        <em>Delivery Boy</em>
                        <span><?php
                            $sql = "SELECT COUNT(*) AS total_delivery_boy FROM delivery_boys";
                            $stmt = $conn->prepare($sql);

                            if ($stmt) {
                                $stmt->execute();
                                $stmt->bind_result($total_delivery_boy);
                                $stmt->fetch();

                                echo $total_delivery_boy;

                                $stmt->close();
                            } else {
                                echo "Error in prepared statement: " . $conn->error;
                            }
                            ?></span>
                    </li>
                </ul>
            </section>


        </div>
        <!-- /.container-fluid -->




        <?php
        include ("includes/scripts.php");
        include ("includes/footer.php");
        ?>
