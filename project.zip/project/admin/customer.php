<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
?>

<style>

    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

    @keyframes bake-pie {
        from {
            transform: rotate(0deg) translate3d(0, 0, 0);
        }
    }

    body {
        font-family: "Open Sans", Arial;
        background: #EEE;
    }

    main {
        width: 400px;
        margin: 30px auto;
    }


    .pieID {
        display: inline-block;
        vertical-align: top;
    }

    .pie {
        height: 200px;
        width: 200px;
        position: relative;
        margin: 0 30px 30px 0;
    }

    .pie::before {
        content: "";
        display: block;
        position: absolute;
        z-index: 1;
        width: 100px;
        height: 100px;
        background: #EEE;
        border-radius: 50%;
        top: 50px;
        left: 50px;
    }

    .pie::after {
        content: "";
        display: block;
        width: 120px;
        height: 2px;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        box-shadow: 0 0 3px 4px rgba(0, 0, 0, 0.1);
        margin: 220px auto;

    }

    .slice {
        position: absolute;
        width: 200px;
        height: 200px;
        clip: rect(0px, 200px, 200px, 100px);
        animation: bake-pie 1s;
    }

    .slice span {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        background-color: black;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        clip: rect(0px, 200px, 200px, 100px);
    }

    .legend {
        list-style-type: none;
        padding: 0;
        margin: 0;
        background: #FFF;
        padding: 15px;
        font-size: 13px;
        box-shadow: 1px 1px 0 #DDD,
            2px 2px 0 #BBB;
    }

    .legend li {
        width: 170px;
        height: 1.25em;
        margin-bottom: 0.7em;
        padding-left: 0.5em;
        border-left: 1.25em solid black;
    }

    .legend em {
        font-style: normal;
    }

    .legend span {
        float: right;
    }

    footer {
        position: fixed;
        bottom: 0;
        right: 0;
        font-size: 13px;
        background: #DDD;
        padding: 5px 10px;
        margin: 5px;
    }

</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#click').click(function (event) {
            event.preventDefault(); // Prevent default form submission behavior
            var query = $("#customerName").val();
            if (query !== '') {
                // Make an Ajax request
                $.ajax({
                    url: 'search.php', // Change to search.php if that's the correct file name
                    type: 'POST',
                    data: {name: query}, // Adjust to match your PHP code
                    success: function (response) {
                        $('#searchResults').html(response);
                    },
                    error: function (xhr, status, error) {
                        console.log(error); // Log the error to the console for debugging
                        alert('Error occurred while processing the request.');
                    }
                });

            } else {
                $('#searchResults').html('');
            }
        });
    });


</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<div class="row md-4">
    <div class="col-sm-5">
        <div class="card-body">
            <section class="d-flex " >
                <div class="pieID pie">

                </div>


                <ul class="pieID legend">
                    <li>

                        <em>Total Customers</em>
                        <span><?php
                            include 'includes/DBconnection.php';

                            $sql = "SELECT COUNT(*) AS total_customers FROM customers";
                            $stmt = $conn->prepare($sql);

                            if ($stmt) {
                                $stmt->execute();
                                $stmt->bind_result($total_customers);
                                $stmt->fetch();

                                echo $total_customers;

                                $stmt->close();
                            } else {
                                echo "Error in prepared statement: " . $conn->error;
                            }
                            ?>
                        </span>
                    </li>
                    <li>
                        <em>Today register customers</em>
                        <span><?php
                            $sql = "SELECT COUNT(*) AS total_customers FROM customers WHERE registration_date = CURDATE()";
                            $stmt = $conn->prepare($sql);

                            if ($stmt) {
                                $stmt->execute();
                                $stmt->bind_result($total_customers);
                                $stmt->fetch();

                                echo $total_customers;

                                $stmt->close();
                            } else {
                                echo "Error in prepared statement: " . $conn->error;
                            }
                            ?>
                        </span>
                    </li>
                    <!--                            <li>
                                                    <em>Delivery Boy</em>
                                                    <span><?php
//                                    $sql = "SELECT COUNT(*) AS total_delivery_boy FROM delivery_boys";
//                                    $result = $conn->query($sql);
//                                    if ($result->num_rows > 0) {
//                                        // Output data for each row
//                                        while ($row = $result->fetch_assoc()) {
//                                            echo $row['total_delivery_boy'];
//                                        }
//                                    } else {
//                                        echo "0 results";
//                                    }
                    ?></span>
                                                </li>-->
                </ul>
            </section>
        </div>
    </div>

    <div class="col-sm-7">
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <td>Total Customers</td>
                        <td>
                            <?php
                            include 'includes/DBconnection.php';

                            $sql = "SELECT COUNT(*) AS total_customers FROM customers";
                            $stmt = $conn->prepare($sql);

                            if ($stmt) {
                                $stmt->execute();
                                $stmt->bind_result($total_customers);
                                $stmt->fetch();

                                echo $total_customers;

                                $stmt->close();
                            } else {
                                echo "Error in prepared statement: " . $conn->error;
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Today registered customers</td>
                        <td>
                            <?php
                            $sql = "SELECT COUNT(*) AS total_customers FROM customers WHERE registration_date = CURDATE()";
                            $stmt = $conn->prepare($sql);

                            if ($stmt) {
                                $stmt->execute();
                                $stmt->bind_result($total_customers);
                                $stmt->fetch();

                                echo $total_customers;

                                $stmt->close();
                            } else {
                                echo "Error in prepared statement: " . $conn->error;
                            }
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
</div>
<div class="container py-5">
    <div class="text-center">
        <h1 class="mb-4">Customer Search</h1>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form method="post" id="searchForm" class="mb-3">
                <div class="input-group">
                    <input type="text" id="customerName" class="form-control" placeholder="Enter Name">
                    <div class="input-group-append">
                        <button id="click" type="submit" class="btn btn-primary">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div id="searchResults" class="container"></div>
<div  class="container">
    <br><br>
    <div class="container">
        <h3>Customer</h3>

        <?php
    echo '<div class="container mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Customer Id</th>
                <th>Customer name</th>
                <th>Email</th>
                <th>Contact no</th>
                <th>Address</th>
                <th>Registration Date</th>
            </tr>
        </thead>
        <tbody>';

// Pagination parameters for Customers
    $entries_per_page_customer = 10;
    $page_customer = isset($_GET['page_customer']) ? $_GET['page_customer'] : 1;
    $start_customer = ($page_customer - 1) * $entries_per_page_customer;

    $sql_customer = "SELECT * FROM customers LIMIT $start_customer, $entries_per_page_customer";
    $result_customer = $conn->query($sql_customer);

    if ($result_customer->num_rows > 0) {
        while ($row = $result_customer->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . @$row['id'] . '</td>';
            echo '<td>' . @$row['name'] . '</td>';
            echo '<td>' . @$row['email'] . '</td>';
            echo '<td>' . @$row['phone'] . '</td>';
            echo '<td>' . @$row['address'] . '</td>';
            echo '<td>' . @$row['registration_date'] . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="6">No records found</td></tr>';
    }

    echo '</tbody>
    </table>

    <nav aria-label="Page navigation">
        <ul class="pagination">';
    $sql_customer_count = "SELECT COUNT(*) AS total FROM customers";
    $result_customer_count = $conn->query($sql_customer_count);
    $row_customer = $result_customer_count->fetch_assoc();
    $total_entries_customer = $row_customer['total'];
    $total_pages_customer = ceil($total_entries_customer / $entries_per_page_customer);

    for ($i = 1; $i <= $total_pages_customer; $i++) {
        echo '<li class="page-item' . ($page_customer == $i ? ' active' : '') . '"><a class="page-link" href="?page_customer=' . $i . '">' . $i . '</a></li>';
    }

    echo '</ul>
    </nav>
</div>';
        ?>
    </div>

    <br><br>
</div>


<?php
include ("includes/scripts.php");
include ("includes/footer.php");
?>
