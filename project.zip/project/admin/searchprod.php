 <?php
 
 $Pname = $_POST['pname'];
    echo '<div class="container mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Products Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact No</th>
                <th>Address</th>
                <th>Shop Name</th>
                <th>Shop Address</th>
                <th>Images</th>
                <th>RegisterDate</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>';

    include 'includes/DBconnection.php';
// Pagination parameters for Products
    $entries_per_page_Products = 10;
    $page_Products = isset($_GET['page_Products']) ? $_GET['page_Products'] : 1;
    $start_Products = ($page_Products - 1) * $entries_per_page_Products;

    $sql_Products = "SELECT * FROM Products WHERE name LIKE '%$Pname%'";
    $result_Products = $conn->query($sql_Products);

    if ($result_Products->num_rows > 0) {
        while ($row = $result_Products->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . @$row['id'] . '</td>';
            echo '<td>' . @$row['name'] . '</td>';
            echo '<td>' . @$row['description'] . '</td>';
            echo '<td>' . @$row['price'] . '</td>';
            echo '<td>' . @$row['quantity'] . '</td>';
            echo '<td>' . @$row['category'] . '</td>';
            echo '<td>' . @$row['brand'] . '</td>';
            echo '<td><img src="' . @$row['image_path'] . '" height="100px" width="100px"></td>';
            echo '<td>' . @$row['product_register_date'] . '</td>';
            echo '<td>' . '<input type="button" class="btn btn-primary" value="Edit" />' . '</td>';
            echo '<td>' . '<input type="button" class="btn btn-primary" value="Delete"/> ' . "</td>";
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="8">No records found</td></tr>';
    }


    echo '</tbody>
</table>

<nav aria-label="Page navigation">
    <ul class="pagination">';
    $sql_Products_count = "SELECT COUNT(*) AS total FROM Products";
    $result_Products_count = $conn->query($sql_Products_count);
    $row_Products = $result_Products_count->fetch_assoc();
    $total_entries_Products = $row_Products['total'];
    $total_pages_Products = ceil($total_entries_Products / $entries_per_page_Products);

    for ($i = 1; $i <= $total_pages_Products; $i++) {
        echo '<li class="page-item' . ($page_Products == $i ? ' active' : '') . '"><a class="page-link" href="?page_Products=' . $i . '">' . $i . '</a></li>';
    }

    echo '</ul>
</nav>
</div>';
    ?>