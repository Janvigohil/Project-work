<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
?>



<style>

    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

    @keyframes bake-pie {
        from {
            transform: rotate(0deg) translate3d(0, 0, 0);
        }
    }

    body {
        font-family: "Open Sans", Arial;
        background: #EEE;
    }

    main {
        width: 400px;
        margin: 30px auto;
    }


    .pieID {
        display: inline-block;
        vertical-align: top;
    }

    .pie {
        height: 200px;
        width: 200px;
        position: relative;
        margin: 0 30px 30px 0;
    }

    .pie::before {
        content: "";
        display: block;
        position: absolute;
        z-index: 1;
        width: 100px;
        height: 100px;
        background: #EEE;
        border-radius: 50%;
        top: 50px;
        left: 50px;
    }

    .pie::after {
        content: "";
        display: block;
        width: 120px;
        height: 2px;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        box-shadow: 0 0 3px 4px rgba(0, 0, 0, 0.1);
        margin: 220px auto;

    }

    .slice {
        position: absolute;
        width: 200px;
        height: 200px;
        clip: rect(0px, 200px, 200px, 100px);
        animation: bake-pie 1s;
    }

    .slice span {
        display: block;
        position: absolute;
        top: 0;
        left: 0;
        background-color: black;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        clip: rect(0px, 200px, 200px, 100px);
    }

    .legend {
        list-style-type: none;
        padding: 0;
        margin: 0;
        background: #FFF;
        padding: 15px;
        font-size: 13px;
        box-shadow: 1px 1px 0 #DDD,
            2px 2px 0 #BBB;
    }

    .legend li {
        width: 170px;
        height: 1.25em;
        margin-bottom: 0.7em;
        padding-left: 0.5em;
        border-left: 1.25em solid black;
    }

    .legend em {
        font-style: normal;
    }

    .legend span {
        float: right;
    }

    footer {
        position: fixed;
        bottom: 0;
        right: 0;
        font-size: 13px;
        background: #DDD;
        padding: 5px 10px;
        margin: 5px;
    }

</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#click').click(function (event) {
            event.preventDefault(); // Prevent default form submission behavior
            var query = $("#vendoname").val();
            if (query !== '') {
                // Make an Ajax request
                $.ajax({
                    url: 'searchvendor.php', // Change to search.php if that's the correct file name
                    type: 'POST',
                    data: {Vname: query}, // Adjust to match your PHP code
                    success: function (response) {
                        $('#searchResults').html(response);
                    },
                    error: function (xhr, status, error) {
                        console.log(error); // Log the error to the console for debugging
                        alert('Error occurred while processing the request.');
                    }
                });

            } else {
                $('#searchResults').html('');
            }
        });
    });


</script>
<div class="card-body">
    <section class="d-flex " >
        <div class="pieID pie">

        </div>
        <ul class="pieID legend">
            <li>
                <em>Delivery Boy</em>
                <span><?php
                    include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';
                    $sql = "SELECT COUNT(*) AS total_vendor FROM delivery_boys";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // Output data for each row
                        while ($row = $result->fetch_assoc()) {
                            echo $row['total_vendor'];
                        }
                    } else {
                        echo "0 results";
                    }
                    ?>
                </span>
            </li>
            <li>

                <em>Today Registered Delivery Boy</em>
                <span><?php
                    $sql = "SELECT COUNT(*) AS total_vendor FROM delivery_boys where registration_date = CURDATE()";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // Output data for each row
                        while ($row = $result->fetch_assoc()) {
                            echo $row['total_vendor'];
                        }
                    } else {
                        echo "0 results";
                    }
                    ?>
                </span>
            </li>
        </ul>
    </section>
</div>

<div class="container">

    <div class="container py-5">
        <div class="text-center">
            <h1 class="mb-4">Delivery Boy Search</h1>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form method="post" id="searchForm" class="mb-3">
                    <div class="input-group">
                        <input type="text" id="vendoname" class="form-control" placeholder="Enter Name">
                        <div class="input-group-append">
                            <button id="click" type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div id="searchResults" class="container"></div>
    <br><br>
    <h3>Delivery Boy</h3>
    <?php
    echo '<div class="container mt-5">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Delivery Boy Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Contact No</th>
                <th>Register Date</th>
            </tr>
        </thead>
        <tbody>';

// Pagination parameters for Delivery Boys
    include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';
    $entries_per_page_delivery_boys = 10;
    $page_delivery_boys = isset($_GET['page_delivery_boys']) ? $_GET['page_delivery_boys'] : 1;
    $start_delivery_boys = ($page_delivery_boys - 1) * $entries_per_page_delivery_boys;

    $sql_delivery_boys = "SELECT `id`, `name`, `email`, `password`, `phone`, `registration_date` FROM `delivery_boys` WHERE 1 LIMIT $start_delivery_boys, $entries_per_page_delivery_boys";
    $result_delivery_boys = $conn->query($sql_delivery_boys);

    if ($result_delivery_boys->num_rows > 0) {
    while ($row = $result_delivery_boys->fetch_assoc()) {
    echo '<tr>';
    echo '<td>' . @$row['id'] . '</td>';
    echo '<td>' . @$row['name'] . '</td>';
    echo '<td>' . @$row['email'] . '</td>';
    echo '<td>' . @$row['password'] . '</td>';
    echo '<td>' . @$row['phone'] . '</td>';
    echo '<td>' . @$row['registration_date'] . '</td>';
    echo '</tr>';
    }
    } else {
    echo '<tr><td colspan="6">No records found</td></tr>';
    }

    echo '</tbody>
    </table>

    <nav aria-label="Page navigation">
        <ul class="pagination">';
    $sql_delivery_boys_count = "SELECT COUNT(*) AS total FROM `delivery_boys` WHERE 1";
    $result_delivery_boys_count = $conn->query($sql_delivery_boys_count);
    $row_delivery_boys = $result_delivery_boys_count->fetch_assoc();
    $total_entries_delivery_boys = $row_delivery_boys['total'];
    $total_pages_delivery_boys = ceil($total_entries_delivery_boys / $entries_per_page_delivery_boys);

    for ($i = 1;
    $i <= $total_pages_delivery_boys;
    $i++) {
    echo '<li class="page-item' . ($page_delivery_boys == $i ? ' active' : '') . '"><a class="page-link" href="?page_delivery_boys=' . $i . '">' . $i . '</a></li>';
    }

    echo '</ul>
    </nav>
</div>';
    ?>


    <br><br>
</div>

<?php
include ("includes/scripts.php");
include ("includes/footer.php");
?>