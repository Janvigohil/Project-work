<?php
session_start(); // Start the session (if not already started)
// Check if the user is logged in
//if (!isset($_SESSION['admin_email'])) {
//    header("Location: login.php");
//    exit();
//}
?>

<?php
include ('includes/header.php');
include ('includes/navbar.php');
include ('includes/nav.php');
?>


<div class="container">
    <div class="row mb-4">

        <div class="col"><br>
            <h2> <img src="img/87388B79-0437-4E5E-B046-9837B4B36CD0.png" height="50" width="50"/> Sales Performance</h2><br>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Metric</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <?php
                try {
                    $dbh = new PDO('mysql:host=localhost;dbname=easymart', 'root', '');
                    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    $stmt = $dbh->prepare('
        SELECT 
            SUM(total_amount) AS total_sales,
            COUNT(order_id) AS total_orders,
            AVG(total_amount) AS avg_order_value
        FROM customer_orders
    ');

                    $stmt->execute();

                    $stmt->bindColumn('total_sales', $totalSales);
                    $stmt->bindColumn('total_orders', $totalOrders);
                    $stmt->bindColumn('avg_order_value', $avgOrderValue);

                    if ($stmt->fetch(PDO::FETCH_BOUND)) {
                        ?>

                        <tbody>
                            <tr>
                                <td>Total Sales</td>
                                <td><?php echo $totalSales ?></td>
                            </tr>
                            <tr>
                                <td>Total Orders</td>
                                <td><?php echo $totalOrders ?></td>
                            </tr>
                            <tr>
                                <td>Average Order Value</td>
                                <td><?php echo $avgOrderValue ?> </td>
                            </tr>
                        </tbody>

                        <?php
                    } else {
                        echo "No data found";
                    }
                } catch (PDOException $e) {
                    echo "Error: " . $e->getMessage();
                }
                ?>

            </table>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col"><br>
            <h2> <img src="img/1714D139-3822-416B-871B-51754F7B2027.png" height="50" width="50"/>  Top Selling Products</h2><br>
            <table class="table table-bordered table-striped">
                <thead >
                    <tr>
                        <th>Product</th>
                        <th>Units Sold</th>
                        <th>Revenue</th>
                    </tr>
                </thead>
                <?php
                try {
                    $dbh = new PDO('mysql:host=localhost;dbname=easymart', 'root', '');
                    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    $stmt = $dbh->prepare('
        SELECT 
            p.name AS product,
            SUM(p.quantity) AS units_sold,
            SUM(p.price) AS revenue
        FROM order_details od
        JOIN products p ON od.product_id = p.id
        GROUP BY od.product_id
        ORDER BY units_sold DESC
        LIMIT 3
    ');

                    $stmt->execute();

                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $product = $row['product'];
                        $unitsSold = $row['units_sold'];
                        $revenue = $row['revenue'];
                        ?>
                        <tbody>
                            <tr>
                                <td><?php echo $product ?></td>
                                <td><?php echo $unitsSold ?> </td>
                                <td><?php echo $revenue ?></td>
                            </tr>
                        </tbody>

                        <?php
                    }
                } catch (PDOException $e) {
                    echo "Error: " . $e->getMessage();
                }
                ?>

            </table>
            <!--            <div class="row mb-4">
                            <div class="col">
                                <canvas id="barChartUnitsSold"></canvas>
            
                            </div>
                            <div class="col">
                                <canvas id="barChartRevenue"></canvas>
            
                            </div>
                            
                            <script>
                                var ctxUnitsSold = document.getElementById('barChartUnitsSold').getContext('2d');
                                var dataUnitsSold = {
                                    labels: <?php echo json_encode($productLabels); ?>,
                                    datasets: [{
                                            label: 'Units Sold',
                                            data: <?php echo json_encode($unitsSoldData); ?>,
                                            backgroundColor: 'rgba(255, 99, 132, 0.7)',
                                            borderColor: 'rgba(255, 99, 132, 1)',
                                            borderWidth: 1
                                        }]
                                };
            
                                var optionsUnitsSold = {
                                    scales: {
                                        y: {
                                            beginAtZero: true
                                        }
                                    },
                                    plugins: {
                                        title: {
                                            display: true,
                                            text: 'Units Sold by Product'
                                        }
                                    }
                                };
            
                                var barChartUnitsSold = new Chart(ctxUnitsSold, {
                                    type: 'bar',
                                    data: dataUnitsSold,
                                    options: optionsUnitsSold
                                });
            
                                var ctxRevenue = document.getElementById('barChartRevenue').getContext('2d');
                                var dataRevenue = {
                                    labels: <?php echo json_encode($productLabels); ?>,
                                    datasets: [{
                                            label: 'Revenue',
                                            data: <?php echo json_encode($revenueData); ?>,
                                            backgroundColor: 'rgba(54, 162, 235, 0.7)',
                                            borderColor: 'rgba(54, 162, 235, 1)',
                                            borderWidth: 1
                                        }]
                                };
            
                                var optionsRevenue = {
                                    scales: {
                                        y: {
                                            beginAtZero: true
                                        }
                                    },
                                    plugins: {
                                        title: {
                                            display: true,
                                            text: 'Revenue by Product'
                                        }
                                    }
                                };
            
                                var barChartRevenue = new Chart(ctxRevenue, {
                                    type: 'bar',
                                    data: dataRevenue,
                                    options: optionsRevenue
                                });
                            </script>
            
                        </div>-->
        </div>

    </div>
    <!--    <div class="row mb-4">
            <div class="col-sm-6">
                           barchart start
    
                <canvas id="barChart" width="400" height="300"></canvas>
    
                barchart end
            </div>
            <div class="col-sm-6">
                <canvas id="barChart2" width="400" height="300"></canvas>
            </div>
        </div>-->
    <br><br>
    <div class="row mb-4">
        <div class="col-sm-4">
            <canvas id="pieChart" width="400" height="200"></canvas>
        </div>
        <div class="col-sm-8"><br>
            <h3><img src="img/image_123650291 (1).JPG" height="50" width="50"/> User Activity</h3><br>
            <table class="table table-bordered table-striped">
                <tbody>
                    <?php
                    try {
                        $dbh = new PDO('mysql:host=localhost;dbname=easymart', 'root', '');
                        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        $stmt = $dbh->prepare('
        SELECT 
            COUNT(id) AS total_users,
            COUNT(CASE WHEN registration_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN 1 END) AS active_users_30_days,
            COUNT(CASE WHEN registration_date = CURDATE() THEN 1 END) AS new_users_30_days
        FROM customers
    ');

                        $stmt->execute();

                        $result = $stmt->fetch(PDO::FETCH_ASSOC);

                        if ($result) {
                            $totalUsers = $result['total_users'];
                            $activeUsers30Days = $result['active_users_30_days'];
                            $newUsers30Days = $result['new_users_30_days'];
                            ?>
                        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

                        <script>
                            var ctx = document.getElementById('pieChart').getContext('2d');

                            var data = {
                                labels: ['Total Users', 'Active Users (last 30 days)', 'New Users (last 30 days)'],
                                datasets: [{
                                        label: 'User Activity',
                                        data: [<?php echo $totalUsers ?>, <?php echo $activeUsers30Days ?>, <?php echo $newUsers30Days ?>],
                                        backgroundColor: [
                                            'rgba(255, 99, 132, 0.7)',
                                            'rgba(54, 162, 235, 0.7)',
                                            'rgba(255, 206, 86, 0.7)'
                                        ],
                                        borderColor: [
                                            'rgba(255, 99, 132, 1)',
                                            'rgba(54, 162, 235, 1)',
                                            'rgba(255, 206, 86, 1)'
                                        ]
                                    }]
                            };

                            var options = {
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        max: Math.max.apply(Math, [<?php echo $totalUsers ?>, <?php echo $activeUsers30Days ?>, <?php echo $newUsers30Days ?>]) + 1
                                    }
                                }
                            };

                            var pieChart = new Chart(ctx, {
                                type: 'pie',
                                data: data,
                                options: options
                            });
                        </script>

                        <tr>
                            <td>Total Users</td>
                            <td><?php echo $totalUsers ?></td>
                        </tr>
                        <tr>
                            <td>Active Users (last 30 days)</td>
                            <td><?php echo $activeUsers30Days ?></td>
                        </tr>
                        <tr>
                            <td>New Users (last 30 days)</td>
                            <td><?php echo $newUsers30Days ?></td>
                        </tr>
                        </tbody> 
                        <?php
                    } else {
                        echo "No data found";
                    }
                } catch (PDOException $e) {
                    echo "Error: " . $e->getMessage();
                }
                ?>


            </table>
        </div>

    </div>

    <div class="row mb-4">
        <div class="col"><br>
            <h3><img src="img/image_123650291 (2).JPG" height="50" width="50"/>    User Engagement</h3><br>
            <table class="table table-bordered table-striped">
                <tbody>
                    <?php
//                    include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';
//
//                    $sql = "SELECT 
//            AVG(session_duration) AS avg_session_duration,
//            AVG(pages_per_session) AS avg_pages_per_session,
//            AVG(bounce_rate) AS avg_bounce_rate
//        FROM user_engagement_data";
//
//                    $result = $conn->query($sql);
//
//                    if ($result->num_rows > 0) {
//                        // Output data of each row
//                        while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td>Average Session Duration</td>
                        <td>4 minutes</td>
                    </tr>
                    <tr>
                        <td>Pages per Session</td>
                        <td>3</td>
                    </tr>
                    <tr>
                        <td>Bounce Rate</td>
                        <td>20%</td>
                    </tr>
                </tbody>

                <?php
//                            echo "Average Session Duration: " . $row["avg_session_duration"] . " seconds<br>";
//                            echo "Average Pages per Session: " . $row["avg_pages_per_session"] . "<br>";
//                            echo "Average Bounce Rate: " . $row["avg_bounce_rate"] . "%<br>";
//                        }
//                    } else {
//                        echo "0 results";
//                    }
//
//                    $conn->close();
                ?>


            </table>
        </div>
    </div>

    <br>
    <h2><img src="img/image_123650291 (3).JPG" height="50" width="50" /> Top Categories by Sales</h2>
    <br>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Category</th>
                <th>Revenue</th>
            </tr>
        </thead>
        <?php
        include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';

        $sql = "SELECT 
            category,
            SUM(price) AS revenue
        FROM order_details od
        JOIN products p ON od.product_id = p.id
        GROUP BY category
        ORDER BY revenue DESC
        LIMIT 3";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            $rank = 1;
            while ($row = $result->fetch_assoc()) {
                ?>
                <tbody>
                    <tr>
                        <td><?php echo $rank ?></td>
                        <?php $rank = $rank + 1; ?>
                        <td><?php echo $row["category"] ?></td>
                        <td><?php echo $row["revenue"] ?></td>
                    </tr>

                </tbody>
                <?php
            }
        } else {
            echo "0 results";
        }

        $conn->close();
        ?>


    </table>
    <br>
    <h2><img src="img/image_123650291.JPG" height="50" width="50" />Top Customers by Revenue</h2>
    <br>
    <table class="table table-bordered table-striped">
        <thead >
            <tr>
                <th>Rank</th>
                <th>Customer</th>
                <th>Total Spent</th>
            </tr>
        </thead>
        <?php
        include 'C:\xampp\htdocs\project\admin\includes\DBconnection.php';

        $sql = "
    SELECT 
        c.name AS customer,
        SUM(co.total_amount) AS total_spent
    FROM customers c
    JOIN customer_orders co ON c.id = co.customer_id
    GROUP BY c.id
    ORDER BY total_spent DESC
    LIMIT 3
";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            $rank = 1;
            while ($row = $result->fetch_assoc()) {
                ?>
                <tbody>
                    <tr>
                        <td><?php echo $rank ?></td>
                        <td><?php echo $row["customer"] ?></td>
                        <td>$<?php echo $row["total_spent"] ?></td>
                    </tr>
                    <?php $rank = $rank + 1; ?>
                </tbody>
                <?php
            }
        } else {
            echo "0 results";
        }

        $conn->close();
        ?>


    </table>
    <canvas id="customerChart" width="400" height="200"></canvas>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
                    var ctx = document.getElementById('customerChart').getContext('2d');

                    var labels = [];
                    var totalSpent = [];

<?php
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "labels.push('" . $row["customer"] . "');";
        echo "totalSpent.push(" . $row["total_spent"] . ");";
    }
}
?>

                    var chart = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                    label: 'Total Spent',
                                    data: totalSpent,
                                    backgroundColor: 'rgba(75, 192, 192, 0.7)',
                                    borderColor: 'rgba(75, 192, 192, 1)',
                                    borderWidth: 1
                                }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    callback: function (value, index, values) {
                                        return '$' + value;
                                    }
                                }
                            }
                        }
                    });
    </script>


    <!-- Add other sections for User Activity, User Engagement, Product Inventory, etc. -->

    <!--    <div class="row mb-4">
            <div class="col">
                <h2>Notes</h2>
                <ul class="list-group">
                    <li class="list-group-item">Sales have increased by 15% compared to the previous month.</li>
                    <li class="list-group-item">New user acquisition strategies have shown positive results.</li>
                    <li class="list-group-item">Some products are running low in stock and need restocking soon.</li>
                </ul>
            </div>
        </div>
    
        <div class="row mb-4">
            <div class="col">
                <h2>Recommendations</h2>
                <ol class="list-group">
                    <li class="list-group-item">Implement a targeted marketing campaign for Category X to increase sales.</li>
                    <li class="list-group-item">Reorder products with low stock to prevent any out-of-stock situations.</li>
                    <li class="list-group-item">Analyze user behavior to identify opportunities for improving engagement.</li>
                </ol>
            </div>-->
</div>

<?php
include ("includes/scripts.php");
include ("includes/footer.php");
?>
